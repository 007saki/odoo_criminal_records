{
    'name': 'Live Chat AI Reply',
    'version': '1.0',
    'summary': 'Respond to visitors using Ollama AI in live chat',
    'category': 'Website',
    'author': 'You',
    'depends': ['website_livechat', 'mail'],
    'data': [],
    'installable': True,
    'auto_install': False,
}
